import java.awt.geom.Point2D;
import java.util.ArrayList;
import java.util.List;

/**
 * PS-2 provided code
 * A point quadtree: stores an element at a 2D position, with children at the subdivided quadrants
 * E extends Point2D to ensure whatever the PointQuadTree holds, it implements getX and getY
 * 
 *
 * @Fatma AL Arbawi: crated insert method, size, findCircleHelper, isPointInCicle, CircleInterRec
 */
public class PointQuadtree<E extends Point2D> {
	private E point;							// the point anchoring this node
	private int x1, y1;							// upper-left corner of the region
	private int x2, y2;							// bottom-right corner of the region
	private PointQuadtree<E> c1, c2, c3, c4;	// children

	/**
	 * Initializes a leaf quadtree, holding the point in the rectangle
	 */
	public PointQuadtree(E point, int x1, int y1, int x2, int y2) {
		this.point = point;
		this.x1 = x1; this.y1 = y1; this.x2 = x2; this.y2 = y2;
	}

	// Getters
	public E getPoint() { return point; }
	public int getX1() { return x1; }
	public int getY1() { return y1; }
	public int getX2() { return x2; }
	public int getY2() { return y2; }

	/**
	 * Returns the child (if any) at the given quadrant, 1-4
	 * @param quadrant	1 through 4
	 * @return child for quadrant
	 */
	public PointQuadtree<E> getChild(int quadrant) {
		if (quadrant==1) return c1;
		if (quadrant==2) return c2;
		if (quadrant==3) return c3;
		if (quadrant==4) return c4;
		return null;
	}

	/**
	 * Returns whether there is a child at the given quadrant, 1-4
	 * @param quadrant	1 through 4
	 */
	public boolean hasChild(int quadrant) {
		return (quadrant==1 && c1!=null) || (quadrant==2 && c2!=null) || (quadrant==3 && c3!=null) || (quadrant==4 && c4!=null);
	}

	/**
	 * Inserts the point into the tree
	 */
	public void insert(E p2) {
		// TODO: YOUR CODE HERE
		//To insert point p, which is at (x',y'), start at the root
		//  If (x',y') is in quadrant 1
		//    If child 1 exists, then recursively insert p in child 1
		//    Else set child 1 to a new tree holding just p and with all children set to null//  And similarly with the other quadrants / children

		if (point == null) {
			point = p2;
			return;
		}
		double midX = (x1 + x2) / 2.0;
		double midY = (y1 + y2) / 2.0;
			if (p2.getX() >= point.getX()) {
				if (p2.getY() >= point.getY()) {
					if (c1 == null) {
						c1 = new PointQuadtree<>(p2, (int) midX, y1, x2, (int) midY);
					} else {
						c1.insert(p2);
					}
				} else {
					if (c4 == null) {
						c4 = new PointQuadtree<>(p2, (int) midX, y1, x2, (int) midY);
					} else {
						c4.insert(p2);
					}
				}
			}else {
				if (p2.getY() >= point.getY()) {
					if (c2 == null) {
						c2 = new PointQuadtree<>(p2, x1, y1, (int)midX, (int)midY);
					}
					else{
						c2.insert(p2);
					}
				}else {
					if (c3 == null){
						c3 = new PointQuadtree<>(p2, x1, (int)midY, (int)midX, y2);
					}
					else{
						c3.insert(p2);
					}
				}
			}
	}
	/**
	 * Finds the number of points in the quadtree (including its descendants)
	 */
	public int size() {
		int count = 0;
		if (point != null) {
			count = 1;
		}

		if (c1 != null) {
			count += c1.size();
		}

		if (c2 != null) {
			count += c2.size();
		}

		if (c3 != null) {
			count += c3.size();
		}

		if (c4 != null) {
			count += c4.size();
		}

		return count;
	}
	
	/**
	 * Builds a list of all the points in the quadtree (including its descendants)
	 * @return List with all points in the quadtree
	 */
	public List<E> allPoints() {
		List <E> allPoints = new ArrayList<>();

		if (point != null) {
			allPoints.add(point);
		}

		if (c1 != null) {
			allPoints.addAll(c1.allPoints());
		}
		if (c2 != null){
			allPoints.addAll(c2.allPoints());
		}
		if (c3 != null){
			allPoints.addAll(c3.allPoints());
		}
		if (c4 != null) {
			allPoints.addAll(c4.allPoints());
		}


	return allPoints;
	}	

	/**
	 * Uses the quadtree to find all points within the circle
	 * @param cx	circle center x
	 * @param cy  	circle center y
	 * @param cr  	circle radius
	 * @return    	the points in the circle (and the qt's rectangle)
	 */
	public List<E> findInCircle(double cx, double cy, double cr) {
		List<E> foundPoint = new ArrayList<>();
		findInCircleHelper(cx, cy, cr, x1, y1, x2, y2, foundPoint);
		return foundPoint;
	}
	private boolean circleInterRec(double cx, double cy, double cr, double x1, double y1, double x2, double y2){
		double closeX = Math.max(x1, Math.min(cx, this.x2 + size()));
		double closeY = Math.max(y1, Math.min(cy, this.y2 + size()));
		double distX = cx - closeX;
		double distY = cy - closeY;
		double distSqr = distX*distX + distY*distY;
		return distSqr <= (cr*cr);
	}
	private boolean isPointInCircle(double px, double py, double cx, double cy, double cr){
		double dx = px - cx;
		double dy = py -cy;
		return(dx*dx + dy*dy) <= (cr * cr);
	}

	private void findInCircleHelper( double cx, double cy, double cr, double x1, double y1, double x2, double y2, List<E> foundPoint) {
		if (!circleInterRec(cx, cy, cr, x1, y1, x2, y2)){
			return;
		}
		if (point != null && isPointInCircle(point.getX(), point.getY(), cx, cy, cr)) {
			foundPoint.add(point);
		}
		double midX = (x1 + x2) / 2;
		double midY = (y1 + y2) / 2;

		if (c1 != null){
			c1.findInCircleHelper(cx, cy, cr, x1, y1, midX, midY, foundPoint);
		}
		if (c2 != null){
			c2.findInCircleHelper(cx, cy, cr, midX, y1, x2, midY, foundPoint);
		}
		if (c3 != null){
			c3.findInCircleHelper(cx, cy, cr, x1, midY, midX, y2, foundPoint);
		}
		if (c4 != null){
			c4.findInCircleHelper(cx, cy, cr, midX, midY, x2, y2, foundPoint);
		}
	}


}
